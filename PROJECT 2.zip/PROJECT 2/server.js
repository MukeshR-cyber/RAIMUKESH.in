const express = require('express');
const path = require('path');
const bodyParser = require('body-parser'); // To parse incoming request bodies

const app = express();

// Static files middleware
app.use(express.static(path.join(__dirname, 'public')));

// Body parser middleware
app.use(bodyParser.json()); // For parsing JSON data
app.use(bodyParser.urlencoded({ extended: true })); // For parsing URL-encoded data

// Placeholder for storing expenses (you can later connect this to a database)
let expenses = [];

// Route to serve the home page (home.html)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Route to serve the login page
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Route to handle incoming SMS data from Twilio
app.post('/sms', (req, res) => {
    const smsContent = req.body.Body; // SMS message content
    const from = req.body.From; // Sender's phone number, if needed for user identification

    // Parse the SMS content to extract expense details
    const expenseData = parseSMS(smsContent);

    if (expenseData) {
        expenses.push(expenseData); // Add to expenses array
        console.log('New expense added:', expenseData);
    }

    // Send an empty response to Twilio
    res.send('<Response></Response>');
});

// Helper function to parse SMS content
function parseSMS(smsContent) {
    // Example SMS format: "Spent $50 on Food at Restaurant on 2024-11-01"
    const regex = /Spent \$(\d+(\.\d{1,2})?) on (\w+) at (.+) on (\d{4}-\d{2}-\d{2})/;
    const match = smsContent.match(regex);

    if (match) {
        return {
            date: match[5],
            description: match[4],
            category: match[3],
            amount: parseFloat(match[1])
        };
    }
    return null; // Return null if SMS does not match the expected format
}

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
